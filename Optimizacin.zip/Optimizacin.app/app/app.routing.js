"use strict";
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var main_menu_component_1 = require("./pages/main_menu/main_menu.component");
var teoria_component_1 = require("./pages/teoria/teoria.component");
var ejemplos_component_1 = require("./pages/ejemplos/ejemplos.component");
var ejercicios_component_1 = require("./pages/ejercicios/ejercicios.component");
var routes = [
    { path: "", redirectTo: "/main_menu", pathMatch: "full" },
    { path: "main_menu", component: main_menu_component_1.MainMenuComponent },
    { path: "ejemplos", component: ejemplos_component_1.ExamplesComponent },
    { path: "ejercicios", component: ejercicios_component_1.ExercisesComponent },
    { path: "teoria", component: teoria_component_1.TheoryComponent }
];
var AppRoutingModule = (function () {
    function AppRoutingModule() {
    }
    return AppRoutingModule;
}());
AppRoutingModule = __decorate([
    core_1.NgModule({
        imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
        exports: [router_1.NativeScriptRouterModule]
    })
], AppRoutingModule);
exports.AppRoutingModule = AppRoutingModule;
