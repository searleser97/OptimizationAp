"use strict";
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var app_routing_1 = require("./app.routing");
var app_component_1 = require("./app.component");
var main_menu_component_1 = require("./pages/main_menu/main_menu.component");
var teoria_component_1 = require("./pages/teoria/teoria.component");
var ejemplos_component_1 = require("./pages/ejemplos/ejemplos.component");
var ejercicios_component_1 = require("./pages/ejercicios/ejercicios.component");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        bootstrap: [
            app_component_1.AppComponent
        ],
        imports: [
            nativescript_module_1.NativeScriptModule,
            app_routing_1.AppRoutingModule
        ],
        declarations: [
            app_component_1.AppComponent,
            main_menu_component_1.MainMenuComponent,
            teoria_component_1.TheoryComponent,
            ejemplos_component_1.ExamplesComponent,
            ejercicios_component_1.ExercisesComponent
        ],
        schemas: [
            core_1.NO_ERRORS_SCHEMA
        ]
    })
], AppModule);
exports.AppModule = AppModule;
