"use strict";
var core_1 = require("@angular/core");
var MainMenuComponent = (function () {
    function MainMenuComponent() {
        this.menuItems = [
            ["Teoría", "teoria", "my-btn-red "],
            ["Ejercicios Resueltos", "ejercicios", "my-btn-blue "],
            ["Ejemplos", "ejemplos", "my-btn-green"]
        ];
    }
    return MainMenuComponent;
}());
MainMenuComponent = __decorate([
    core_1.Component({
        selector: 'main-menu',
        templateUrl: "pages/main_menu/main_menu.component.html",
        styleUrls: ['pages/main_menu/main_menu.component.css']
    })
], MainMenuComponent);
exports.MainMenuComponent = MainMenuComponent;
