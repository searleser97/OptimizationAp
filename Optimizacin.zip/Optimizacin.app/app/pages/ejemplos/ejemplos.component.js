"use strict";
var core_1 = require("@angular/core");
var ExamplesComponent = (function () {
    function ExamplesComponent() {
    }
    return ExamplesComponent;
}());
ExamplesComponent = __decorate([
    core_1.Component({
        selector: "examples",
        templateUrl: "pages/ejemplos/ejemplos.component.html",
        styleUrls: ["pages/ejemplos/ejemplos.component.css"]
    })
], ExamplesComponent);
exports.ExamplesComponent = ExamplesComponent;
