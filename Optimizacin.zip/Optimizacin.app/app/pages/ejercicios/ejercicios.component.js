"use strict";
var fs = require("file-system");
var core_1 = require("@angular/core");
var ExercisesComponent = (function () {
    function ExercisesComponent() {
        this.pdfSrc = "";
        var currentAppFolder = fs.knownFolders.currentApp();
        this.pdfSrc = currentAppFolder.path + "/appFiles/ejemplosOptimizacion.pdf";
        // this.pdfSrc = "https://www.princexml.com/samples/invoice/invoicesample.pdf";
    }
    return ExercisesComponent;
}());
ExercisesComponent = __decorate([
    core_1.Component({
        selector: "exercises",
        templateUrl: "pages/ejercicios/ejercicios.component.html",
        styleUrls: ["pages/ejercicios/ejercicios.component.css"]
    }),
    __metadata("design:paramtypes", [])
], ExercisesComponent);
exports.ExercisesComponent = ExercisesComponent;
