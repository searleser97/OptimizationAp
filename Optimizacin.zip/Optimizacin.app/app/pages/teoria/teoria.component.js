"use strict";
var core_1 = require("@angular/core");
var web_view_1 = require("ui/web-view");
var page_1 = require("ui/page");
var fs = require("file-system");
var TheoryComponent = (function () {
    function TheoryComponent(page) {
        this.page = page;
    }
    TheoryComponent.prototype.ngOnInit = function () {
        var currentAppFolder = fs.knownFolders.currentApp();
        this.webViewSrc = currentAppFolder.path + "/pages/teoria/teoria.html";
        var webview = this.page.getViewById("wv");
        webview.on(web_view_1.WebView.loadStartedEvent, function (args) {
            if (!args.error) {
                if (webview.android) {
                    webview.android.getSettings().setBuiltInZoomControls(false);
                }
            }
            else {
                alert('Oops!, something went wrong!, try again later.');
            }
        });
    };
    return TheoryComponent;
}());
TheoryComponent = __decorate([
    core_1.Component({
        selector: "theory",
        templateUrl: "pages/teoria/teoria.component.html",
        styleUrls: ["pages/teoria/teoria.component.css"]
    }),
    __metadata("design:paramtypes", [page_1.Page])
], TheoryComponent);
exports.TheoryComponent = TheoryComponent;
